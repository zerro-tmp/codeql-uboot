/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * (C) Copyright 2018
 * Mario Six,  Guntermann & Drunck GmbH, mario.six@gdsys.cc
 */

enum {
	BOOL_CALLED_DETECT,
	INT_TEST1,
	INT_TEST2,
	STR_VACATIONSPOT,
};
