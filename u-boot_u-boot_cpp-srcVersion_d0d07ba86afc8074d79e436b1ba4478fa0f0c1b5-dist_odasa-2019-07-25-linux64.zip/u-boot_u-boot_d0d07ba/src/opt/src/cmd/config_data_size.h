static const size_t data_size = 
33141
;
