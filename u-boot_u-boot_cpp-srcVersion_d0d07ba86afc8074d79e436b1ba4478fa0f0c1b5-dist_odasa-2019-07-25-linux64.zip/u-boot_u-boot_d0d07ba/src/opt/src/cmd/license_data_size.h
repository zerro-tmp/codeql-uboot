static const size_t data_size = 
18092
;
